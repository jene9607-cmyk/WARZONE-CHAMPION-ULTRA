package com.warzone.champion

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import com.google.android.gms.tasks.Task
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private val serviceId = "com.warzone.champion.localgame"
    private val strategy = Strategy.P2P_CLUSTER
    private val connections = ConcurrentHashMap<String, String>() // endpointId -> display name
    private var advertising = false
    private var discovering = false
    private val permissionsRequest = 701

    private val connectionLifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            Nearby.getConnectionsClient(this@MainActivity).acceptConnection(endpointId, payloadCallback)
        }
        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                if (connections.size >= 7 && !connections.containsKey(endpointId)) {
                    Nearby.getConnectionsClient(this@MainActivity).disconnectFromEndpoint(endpointId)
                    status("Room is full: maximum 8 players including host")
                    return
                }
                connections[endpointId] = "Player ${connections.size + 2}"
                status("Connected to ${connections.size} nearby player(s). No internet required.")
                broadcast(JSONObject().put("type", "hello").put("name", "Player").toString())
            } else status("Connection failed. Keep Wi-Fi and Bluetooth enabled, then retry.")
            updateCount()
        }
        override fun onDisconnected(endpointId: String) {
            connections.remove(endpointId)
            status("A player disconnected. Nearby players: ${connections.size}")
            updateCount()
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            val bytes = payload.asBytes() ?: return
            val text = String(bytes, StandardCharsets.UTF_8)
            val safeText = JSONObject.quote(text)
            val safeId = JSONObject.quote(endpointId)
            runOnUiThread { web.evaluateJavascript("window.onNearbyMessage && window.onNearbyMessage($safeId,$safeText)", null) }
        }
        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) { }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(NativeBridge(), "WarzoneNative")
        setContentView(web)
        web.loadUrl("file:///android_asset/game/index.html")
    }

    private inner class NativeBridge {
        @JavascriptInterface fun startNearby() { runOnUiThread { ensurePermissionsThenStart() } }
        @JavascriptInterface fun sendGameMessage(message: String) { broadcast(message) }
        @JavascriptInterface fun stopNearby() { runOnUiThread { stopNearby() } }
    }

    private fun requiredPermissions(): Array<String> {
        val p = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            p += Manifest.permission.BLUETOOTH_SCAN
            p += Manifest.permission.BLUETOOTH_ADVERTISE
            p += Manifest.permission.BLUETOOTH_CONNECT
        } else if (Build.VERSION.SDK_INT >= 23) p += Manifest.permission.ACCESS_FINE_LOCATION
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.NEARBY_WIFI_DEVICES
        return p.distinct().toTypedArray()
    }

    private fun ensurePermissionsThenStart() {
        val missing = requiredPermissions().filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) { ActivityCompat.requestPermissions(this, missing.toTypedArray(), permissionsRequest); return }
        startNearby()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionsRequest && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startNearby()
        else status("Nearby permissions are needed for offline discovery. Enable them and tap Auto-Discover again.")
    }

    private fun startNearby() {
        if (advertising || discovering) { status("Already searching for nearby players…"); return }
        val client = Nearby.getConnectionsClient(this)
        val options = AdvertisingOptions.Builder().setStrategy(strategy).build()
        client.startAdvertising("Warzone-${Build.MODEL.take(12)}", serviceId, connectionLifecycle, options)
            .addOnSuccessListener { advertising = true; status("Advertising locally. Searching for players… no internet server.") }
            .addOnFailureListener { status("Could not advertise: ${it.localizedMessage ?: "check Bluetooth/Wi-Fi permissions"}") }
        val discoveryOptions = DiscoveryOptions.Builder().setStrategy(strategy).build()
        client.startDiscovery(serviceId, object : EndpointDiscoveryCallback() {
            override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
                if (connections.size >= 7 || connections.containsKey(endpointId)) return
                client.requestConnection("Warzone player", endpointId, connectionLifecycle)
                    .addOnFailureListener { status("Could not connect to nearby player. Retry discovery.") }
            }
            override fun onEndpointLost(endpointId: String) { }
        }, discoveryOptions).addOnSuccessListener { discovering = true; status("Automatic discovery active. Keep Bluetooth and Wi-Fi enabled; up to 8 players total.") }
            .addOnFailureListener { status("Discovery failed: ${it.localizedMessage ?: "check permissions"}") }
    }

    private fun broadcast(message: String) {
        if (connections.isEmpty()) return
        val payload = Payload.fromBytes(message.toByteArray(StandardCharsets.UTF_8))
        Nearby.getConnectionsClient(this).sendPayload(connections.keys.toList(), payload)
    }

    private fun updateCount() { status("Nearby players connected: ${connections.size} / 7 guests (8 total maximum)") }
    private fun status(message: String) {
        runOnUiThread {
            if (::web.isInitialized) web.evaluateJavascript("window.onNearbyStatus && window.onNearbyStatus(${JSONObject.quote(message)},${connections.size})", null)
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
    }
    private fun stopNearby() {
        Nearby.getConnectionsClient(this).stopAdvertising(); Nearby.getConnectionsClient(this).stopDiscovery(); Nearby.getConnectionsClient(this).stopAllEndpoints()
        advertising = false; discovering = false; connections.clear(); status("Nearby multiplayer stopped.")
    }
    override fun onDestroy() { stopNearby(); if (::web.isInitialized) web.destroy(); super.onDestroy() }
}

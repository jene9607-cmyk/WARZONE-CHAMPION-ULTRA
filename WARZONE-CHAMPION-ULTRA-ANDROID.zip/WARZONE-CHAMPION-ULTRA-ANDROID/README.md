# WARZONE CHAMPION ULTRA — Native Android Offline Multiplayer

This is an **Android Studio source project**, not a prebuilt APK. It wraps the local HTML game in an Android WebView and adds native Nearby Connections discovery. The native transport uses Google Play services Nearby Connections with `P2P_CLUSTER`, advertises and discovers locally, automatically requests connections, and sends game state/shot packets to connected peers. It does not use an online game server.

## What this version adds
- Native Android app shell, landscape mode and immersive display.
- Local HTML game and icon assets bundled inside the APK, so solo play does not need a website or internet.
- Nearby discovery via Android Nearby Connections, using Bluetooth/Wi-Fi radios; no manual WebRTC codes in the Android app path.
- Connection cap: host-side UI logic limits to host + seven guests (8 total).
- A JavaScript bridge to send/receive game packets.

## Build the APK
1. On a computer, install Android Studio and Android SDK Platform 35.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `WARZONE-CHAMPION-ULTRA-ANDROID` folder.
4. Allow Gradle sync and install the requested SDK/dependencies. The first build needs internet to download Android/Google Play Services dependencies; gameplay itself is bundled locally.
5. Build > Build APK(s), then install the APK on Android phones.
6. On each phone, enable Bluetooth and Wi-Fi. Internet is not needed for the nearby session, but Google Play services must be present and working on the phones. Tap **AUTO-DISCOVER NEARBY** on each device and approve the requested permissions.

## Important limitations / testing status
- This is source code for a native prototype; no APK was compiled or tested on physical phones in this environment.
- Nearby Connections is offline peer-to-peer but depends on Android Google Play services. It is not guaranteed on devices without GMS. Local radio conditions and OEM permissions can affect discovery.
- P2P_CLUSTER is used for multi-device sessions. Eight-device stability must be tested on actual phones.
- The current game synchronization is still prototype-level: player states and shot events are exchanged, but this does **not** yet implement authoritative shared health, enemy AI, bullet-hit validation, collision consistency, objectives, anti-cheat, reconnection, or a fully deterministic shared match. Treat this as a working base for testing, not a finished commercial game.
- The project still requires internet once on a development computer to resolve dependencies and build. The installed game's single-player assets are local.

## Controls
Mobile joysticks and action buttons are included in the local game page. The app launches directly into the game from bundled assets.
